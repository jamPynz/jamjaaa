import React from "react";
import { Register } from "@/components/template/Register";

const Page = () => {
  return (
    <div className="flex justify-center">
      <Register />
    </div>
  );
};

export default Page;
